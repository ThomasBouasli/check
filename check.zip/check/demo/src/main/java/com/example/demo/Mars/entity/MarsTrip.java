package com.example.demo.Mars.entity;

import java.util.Date;
import java.util.regex.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class MarsTrip {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date departureDate;
    private int durationInDays;
    private int numberOfSeats;

    private String planeName;

    public String getPlaneName() {
        return planeName;
    }

    public void setPlaneName(String planeName) {

        Pattern pattern = Pattern.compile("[a-zA-Z]{4}-[0-9]{4}");

        if (!pattern.matcher(planeName).matches()) {
            throw new IllegalArgumentException("Plane name must be in format aaaa-9999");
        }

        this.planeName = planeName;
    }

    private String capitanName;
    private String capitanCode;
    private String coCapitanName;
    private String coCapitanCode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(Date departureDate) {
        this.departureDate = departureDate;
    }

    public int getDurationInDays() {
        return durationInDays;
    }

    public void setDurationInDays(int durationInDays) {

        if (durationInDays < 1) {
            throw new IllegalArgumentException("Duration must be at least 1 day");
        }

        this.durationInDays = durationInDays;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {

        if (numberOfSeats % 3 != 0) {
            throw new IllegalArgumentException("Number of seats must be a multiple of 3");
        }

        if (numberOfSeats < 1) {
            throw new IllegalArgumentException("Number of seats must be at least 1");
        }

        this.numberOfSeats = numberOfSeats;
    }

    public String getCapitanName() {
        return capitanName;
    }

    public void setCapitanName(String capitanName) {
        this.capitanName = capitanName;
    }

    public String getCapitanCode() {
        return capitanCode;
    }

    public void setCapitanCode(String capitanCode) {

        Pattern pattern = Pattern.compile("[a-zA-Z]{3}-[0-9]{4}-[a-zA-Z][0-9][a-zA-Z]");

        if (!pattern.matcher(capitanCode).matches()) {
            throw new IllegalArgumentException("Capitan code must be in format XXX-9999-X9X");
        }

        this.capitanCode = capitanCode;
    }

    public String getCoCapitanName() {
        return coCapitanName;
    }

    public void setCoCapitanName(String coCapitanName) {

        Pattern pattern = Pattern.compile("[a-zA-Z]{3}-[0-9]{4}-[a-zA-Z][0-9][a-zA-Z]");

        if (!pattern.matcher(capitanCode).matches()) {
            throw new IllegalArgumentException("Capitan code must be in format XXX-9999-X9X");
        }

        this.coCapitanName = coCapitanName;
    }

    public String getCoCapitanCode() {

        return coCapitanCode;
    }

    public void setCoCapitanCode(String coCapitanCode) {
        this.coCapitanCode = coCapitanCode;
    }

}
