package com.example.demo.Mars;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.Mars.entity.MarsTrip;
import com.example.demo.Mars.repository.MarsTripRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@RequestMapping("/mars")
@Controller
public class MarsController {

    @Autowired
    private MarsTripRepository repository;

    @GetMapping("")
    public ModelAndView list() {
        ModelAndView modelAndView = new ModelAndView("mars/list/index");
        modelAndView.addObject("marsTrips", repository.findAll());

        return modelAndView;
    }

    @GetMapping("/create")
    public ModelAndView create() {
        ModelAndView modelAndView = new ModelAndView("mars/form/index");
        return modelAndView;
    }

    @GetMapping("/update/{id}")
    public ModelAndView update(@PathVariable("id") String id) {
        ModelAndView modelAndView = new ModelAndView("mars/form/update");

        MarsTrip trip = repository.findById(Long.parseLong(id)).get();

        modelAndView.addObject("marsTrip", trip);

        modelAndView.addObject("id", id);
        return modelAndView;
    }

    @PostMapping("/create")
    public String save(@ModelAttribute("marsTrip") MarsTrip marsTrip) {

        repository.save(marsTrip);

        return "redirect:/mars";
    }

    @PostMapping("/update")
    public String update(@ModelAttribute("marsTrip") MarsTrip marsTrip) {
        repository.save(marsTrip);
        return "redirect:/mars";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable("id") String id) {
        repository.deleteById(Long.parseLong(id));
        return "redirect:/mars";
    }
}
