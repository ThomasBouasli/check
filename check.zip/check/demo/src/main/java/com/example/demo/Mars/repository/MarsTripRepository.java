package com.example.demo.Mars.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.Mars.entity.MarsTrip;

public interface MarsTripRepository extends CrudRepository<MarsTrip, Long> {

}
